
# Water Quality Prediction using Machine Learning

Domain - Applied Data Science



## Team Members
- Deeksha Navde
- Shivani Chhachhar

# Directory Tree
```bash
.
├── Members
│   ├── Team Member 1
│   ├── Team Member 2
│
├── Final Deliverables
│   ├── Static
│   ├── templates
│   ├── Links.txt
│   ├── Water_quality.ipynb
│   ├── app.py
│   ├── model.pkl
│   ├── requirements.txt
│   └── water_potability.csv
├── Screenshots
│   ├── Home Page.png
└── README.md
